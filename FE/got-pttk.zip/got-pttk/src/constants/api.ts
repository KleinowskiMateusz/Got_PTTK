/* eslint-disable import/prefer-default-export */
export const BACKEND_URL = 'http://192.168.100.2:8080'

export const ASSETS_URL = `${BACKEND_URL}/potwierdzenie/zdjecie`

export const ROUTES_URL = `${BACKEND_URL}/odcinek`
export const PRIVATE_ROUTES_URL = `${BACKEND_URL}/wycieczka/odcinekPrywatny`
export const POINTS_URL = `${BACKEND_URL}/wycieczka/dostepnePunkty`
export const TRIPS_URL = `${BACKEND_URL}/wycieczka/wycieczka`
export const ADJUSTED_ROUTES_URL = `${BACKEND_URL}/wycieczka/przylegajaceOdcinki`
export const CONFIRMATION_URL = `${BACKEND_URL}/potwierdzenie`
export const CONFIRMATION_IMAGE_URL = `${CONFIRMATION_URL}/zdjecie`
export const CONFIRMATION_ADD_URL = `${CONFIRMATION_URL}/zezdjeciem`
export const VERIFICATION_URL = `${BACKEND_URL}/weryfikacja`
export const VERIFICATION_TRIPS_URL = `${BACKEND_URL}/weryfikacja/wycieczki`
export const VERIFICATION_TRIP_URL = `${BACKEND_URL}/weryfikacja/wycieczka`
export const MOUNTAIN_RANGES_URL = `${BACKEND_URL}/wycieczka/dostepnePasmaGorskie/1`
