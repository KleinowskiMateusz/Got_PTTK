import { createStore } from 'redux'
import Reducer from './reducer'

export default () => createStore(Reducer)
