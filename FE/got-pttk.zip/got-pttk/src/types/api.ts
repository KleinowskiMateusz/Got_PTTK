export type RoutePostData = {
  nazwa: string
  punkty: number
  punktyPowrot: number
  od: number
  do: number
  pasmo: number
}

export type TripPostData = {
  wlasciciel: string
  nazwa: string
  przebyteOdcinki: { kolejnosc: number; odcinekId: number; powrot: boolean }[]
}

export type VerificationPostData = {
  wycieczka: number
  przodownik: string
  zaakceptiowana: boolean
  powodOdrzucenia: string | null
}

export type ConfirmationPostData = {
  PunktId: number
  OdcinekId: number
  Url?: ''
  Image: string
}
