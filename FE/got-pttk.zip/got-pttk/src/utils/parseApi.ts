/* eslint-disable import/prefer-default-export */
import {
  MountainRange,
  Confirmation,
  Point,
  Route,
  Trip,
  VerificationTrip,
} from '../types/gotpttk'

export const parseMountainRange = (apiMountainRange: any): MountainRange => ({
  id: apiMountainRange.id,
  name: apiMountainRange.nazwa,
})

export const parseConfirmation = (
  apiConfirmation: any,
  routeID: Route['id'] | undefined = undefined
): Confirmation => ({
  id: apiConfirmation.id,
  type: apiConfirmation.typ === 1 ? 'image' : 'qr',
  src: apiConfirmation.url,
  date: new Date(apiConfirmation.data),
  pointID: apiConfirmation.punktTerenowy.id,
  routeID,
})

export const parsePoint = (apiPoint: any): Point => ({
  id: apiPoint.id,
  lat: apiPoint.lat,
  lng: apiPoint.lng,
  mnpm: apiPoint.mnpm,
  name: apiPoint.nazwa,
})

export const parseRoute = (apiRoute: any, reverse = false): Route => {
  const parsedToPoint = parsePoint(apiRoute.punktTerenowyDo)
  const parsedFromPoint = parsePoint(apiRoute.punktTerenowyOd)

  return {
    id: apiRoute.id,
    name: apiRoute.nazwa,
    direction: `Z ${reverse ? parsedToPoint.name : parsedFromPoint.name} do ${
      reverse ? parsedFromPoint.name : parsedToPoint.name
    }`,
    points: {
      to: reverse ? apiRoute.punkty : apiRoute.punktyPowrot,
      from: reverse ? apiRoute.punktyPowrot : apiRoute.punkty,
    },
    from: reverse ? parsedToPoint : parsedFromPoint,
    to: reverse ? parsedFromPoint : parsedToPoint,
    mountainRange: apiRoute.pasmoGorskie.nazwa,
    owned: Boolean(apiRoute.wlasciciel),
    return: Boolean(reverse),
  }
}

export const parseTrip = (apiTrip: any): Trip => ({
  id: apiTrip.id,
  name: apiTrip.nazwa,
  status: String(apiTrip.status),
  owner: apiTrip.ksiazeczka.wlasciciel,
  routes:
    apiTrip.odcinki.map((route: any) =>
      parseRoute(route.odcinek, !route.powrot)
    ) || [],
})

export const parseVerificationTrip = (
  apiVerificationTrip: any
): VerificationTrip => ({
  startDate: new Date(apiVerificationTrip.dataPoczatkowa),
  endDate: new Date(apiVerificationTrip.dataKoncowa),
  location: apiVerificationTrip.lokalizacja,
  confirmations: apiVerificationTrip.wycieczka.odcinki
    ? apiVerificationTrip.wycieczka.odcinki.reduce(
        (acc: Confirmation[], route: any) => [
          ...acc,
          ...(route.potwierdzenia
            ? route.potwierdzenia.map((confirmation: any) =>
                parseConfirmation(
                  confirmation.potwierdzenieTerenowe,
                  route.odcinek.id
                )
              )
            : []),
        ],
        []
      )
    : [],
  ...parseTrip(apiVerificationTrip.wycieczka),
})
